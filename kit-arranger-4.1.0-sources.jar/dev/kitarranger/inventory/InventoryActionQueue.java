package dev.kitarranger.inventory;

import dev.kitarranger.config.KitArrangerSettings;
import dev.kitarranger.util.NotificationManager;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Queue;
import java.util.function.BiConsumer;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_490;
import net.minecraft.class_7923;

public final class InventoryActionQueue {
    private final KitArrangerSettings settings;
    private final Queue<Action> actions = new ArrayDeque<>();
    private class_1723 handler;
    private Runnable onComplete = () -> { };
    private Runnable onCancel = () -> { };
    private BiConsumer<Integer, Integer> onProgress = (done, total) -> { };
    private Action awaiting;
    private long nextActionAt;
    private long actionSentAt;
    private int completedActions;
    private int totalMoves;
    private boolean running;

    public InventoryActionQueue(KitArrangerSettings settings) { this.settings = settings; }

    public void enqueue(class_1723 handler, Collection<Action> planned, int totalMoves,
                        BiConsumer<Integer, Integer> onProgress, Runnable onComplete, Runnable onCancel) {
        cancel(null);
        this.handler = handler;
        this.actions.addAll(planned);
        this.totalMoves = Math.max(0, totalMoves);
        this.completedActions = 0;
        this.onProgress = onProgress == null ? (done, total) -> { } : onProgress;
        this.onComplete = onComplete == null ? () -> { } : onComplete;
        this.onCancel = onCancel == null ? () -> { } : onCancel;
        this.awaiting = null;
        this.nextActionAt = 0L;
        this.running = !actions.isEmpty();
    }

    public void tick(class_310 client) {
        if (!running) return;
        if (client.field_1724 == null || client.field_1761 == null
                || !(client.field_1755 instanceof class_490)
                || client.field_1724.field_7512 != handler) {
            cancel(client);
            return;
        }
        long now = System.currentTimeMillis();
        if (awaiting != null) {
            if (sameStack(handler.method_7611(awaiting.slot()).method_7677(), awaiting.after())) {
                actions.remove();
                completedActions++;
                if (completedActions % 3 == 0 || actions.isEmpty()) {
                    onProgress.accept(Math.min(totalMoves, (completedActions + 2) / 3), totalMoves);
                }
                awaiting = null;
                nextActionAt = now + Math.max(20, Math.min(100, settings.actionDelayMs()));
                if (actions.isEmpty()) finish();
                return;
            }
            if (now - actionSentAt < Math.max(1000L, settings.actionDelayMs() * 8L)) return;
            cancel(client);
            return;
        }
        if (now < nextActionAt) return;

        Action action = actions.peek();
        if (action == null) {
            finish();
            return;
        }
        if (action.slot() < 5 || action.slot() > 45 || action.slot() >= handler.field_7761.size()
                || !sameStack(handler.method_7611(action.slot()).method_7677(), action.expected())) {
            cancel(client);
            return;
        }

        client.field_1761.method_2906(handler.field_7763, action.slot(), 0, class_1713.field_7790, client.field_1724);
        awaiting = action;
        actionSentAt = now;
    }

    public boolean isRunning() { return running; }

    public void cancel(class_310 client) {
        if (!running) {
            actions.clear();
            return;
        }
        running = false;
        actions.clear();
        awaiting = null;
        onProgress = (done, total) -> { };
        Runnable callback = onCancel;
        onCancel = () -> { };
        callback.run();
        if (client != null) NotificationManager.warn(client, "Inventory changed — arrangement cancelled");
    }

    private void finish() {
        running = false;
        actions.clear();
        awaiting = null;
        onProgress.accept(totalMoves, totalMoves);
        onProgress = (done, total) -> { };
        Runnable callback = onComplete;
        onComplete = () -> { };
        callback.run();
    }

    private static boolean sameStack(class_1799 left, class_1799 right) {
        if (left.method_7960() || right.method_7960()) return left.method_7960() && right.method_7960();
        return left.method_7947() == right.method_7947()
                && class_7923.field_41178.method_10221(left.method_7909()).equals(class_7923.field_41178.method_10221(right.method_7909()))
                && left.method_57353().toString().equals(right.method_57353().toString());
    }

    public record Action(int slot, class_1799 expected, class_1799 after) { }
}
