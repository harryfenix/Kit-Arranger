package dev.kitarranger.inventory;

import dev.kitarranger.profile.KitProfile;
import net.minecraft.class_1799;
import net.minecraft.class_7923;

public final class InventoryMatcher {
    private InventoryMatcher() { }

    public static boolean matches(class_1799 current, KitProfile.SavedSlot saved) {
        if (current == null || current.method_7960() || saved == null) return false;
        if (!class_7923.field_41178.method_10221(current.method_7909()).toString().equals(saved.itemId)) return false;
        return current.method_57353().toString().equals(saved.components);
    }
}
