package dev.kitarranger.mixin;

import dev.kitarranger.KitArrangerClient;
import dev.kitarranger.profile.KitProfile;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_490;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_490.class)
public abstract class InventoryScreenMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void kitarranger$renderOverlay(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        class_490 screen = (class_490) (Object) this;
        KitArrangerClient mod = KitArrangerClient.get();
        if (mod == null) return;
        KitProfile profile = mod.getProfileManager().getActiveProfile();
        int x = (screen.field_22789 - 176) / 2;
        int y = (screen.field_22790 - 166) / 2;
        int cardWidth = 174;
        int cardHeight = 58;
        int cardX = x + 188;
        if (cardX + cardWidth > screen.field_22789 - 4) cardX = x - cardWidth - 12;
        if (cardX < 4) cardX = 4;
        context.method_25294(cardX, y, cardX + cardWidth, y + cardHeight, 0xE0101820);
        context.method_25294(cardX, y, cardX + cardWidth, y + 2, 0xFF43D17A);
        context.method_27535(screen.method_64506(), class_2561.method_43470("KIT ARRANGER v" + KitArrangerClient.VERSION), cardX + 8, y + 7, 0xFFFFFF);
        String activeName = profile == null ? "No active kit" : profile.name;
        String scope = mod.getProfileManager().getCurrentScope();
        if (scope.length() > 22) scope = scope.substring(0, 19) + "...";
        context.method_27535(screen.method_64506(), class_2561.method_43470("Kit: " + activeName), cardX + 8, y + 21, 0x71D38A);
        context.method_27535(screen.method_64506(), class_2561.method_43470("Scope: " + scope), cardX + 8, y + 34, 0xA8B0BC);
        context.method_27535(screen.method_64506(), class_2561.method_43470("By " + KitArrangerClient.CREATOR), cardX + 8, y + 47, 0xD8E4EA);
        if (mod.getSettings().showProfileName() && profile != null) {
            context.method_27535(screen.method_64506(), class_2561.method_43470("Active Kit: " + profile.name), x, y - 12, 0x71D38A);
        }
        if (profile == null || !mod.getSettings().highlightKitItems()) return;
        for (class_1735 slot : screen.method_17577().field_7761) {
            if (profile.slots.containsKey(slot.field_7874)) {
                context.method_25294(x + slot.field_7873 - 1, y + slot.field_7872 - 1, x + slot.field_7873 + 17, y + slot.field_7872 + 17, 0x5538D978);
            }
        }
    }
}
