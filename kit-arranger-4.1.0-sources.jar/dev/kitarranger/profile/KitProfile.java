package dev.kitarranger.profile;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1661;
import net.minecraft.class_1723;
import net.minecraft.class_1799;
import net.minecraft.class_7923;

public final class KitProfile {
    public String name;
    public String scope = "global";
    public Map<Integer, SavedSlot> slots = new LinkedHashMap<>();

    public KitProfile() { }
    public KitProfile(String name) { this.name = name; }

    public static KitProfile capture(String name, class_1661 inventory) {
        return capture(name, inventory, "global");
    }

    public static KitProfile capture(String name, class_1661 inventory, String scope) {
        KitProfile profile = new KitProfile(name);
        profile.scope = scope == null || scope.isBlank() ? "global" : scope;
        class_1723 handler = new class_1723(inventory, false, inventory.field_7546);
        for (int id = 5; id <= 45 && id < handler.field_7761.size(); id++) {
            class_1799 stack = handler.method_7611(id).method_7677();
            if (!stack.method_7960()) profile.slots.put(id, SavedSlot.from(stack));
        }
        return profile;
    }

    public static final class SavedSlot {
        public int count;
        public String itemId;
        public String components;

        public static SavedSlot from(class_1799 stack) {
            SavedSlot saved = new SavedSlot();
            saved.count = stack.method_7947();
            saved.itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
            saved.components = stack.method_57353().toString();
            return saved;
        }
    }
}
