package dev.kitarranger.ui;

import dev.kitarranger.KitArrangerClient;
import dev.kitarranger.profile.KitProfile;
import dev.kitarranger.profile.ProfileManager;
import dev.kitarranger.util.NotificationManager;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class ProfileSelectorScreen extends class_437 {
    private final class_437 parent;

    public ProfileSelectorScreen(class_437 parent) {
        super(class_2561.method_43470("Kit Arranger v" + KitArrangerClient.VERSION + " Dashboard"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        ProfileManager manager = KitArrangerClient.get().getProfileManager();
        int left = field_22789 / 2 - 170;
        int top = 50;
        int index = 0;
        for (KitProfile profile : manager.getScopedProfiles()) {
            int y = top + index++ * 27;
            String label = profile.name.equals(manager.getActiveName()) ? "✓ " + profile.name : profile.name;
            method_37063(class_4185.method_46430(class_2561.method_43470(label), button -> select(profile))
                    .method_46434(left, y, 145, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("Copy"), button -> {
                String copy = manager.duplicate(profile.name);
                if (copy != null) NotificationManager.success(field_22787, "Duplicated " + copy);
                field_22787.method_1507(new ProfileSelectorScreen(parent));
            }).method_46434(left + 150, y, 62, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("Delete"), button -> {
                manager.delete(profile.name);
                field_22787.method_1507(new ProfileSelectorScreen(parent));
            }).method_46434(left + 217, y, 62, 20).method_46431());
        }

        int footerY = field_22790 - 32;
        method_37063(class_4185.method_46430(class_2561.method_43470("Export Active"), button -> {
            NotificationManager.info(field_22787, manager.exportActive() ? "Active profile exported" : "No active profile to export");
        }).method_46434(field_22789 / 2 - 170, footerY, 105, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Import"), button -> {
            int imported = manager.importProfiles();
            NotificationManager.info(field_22787, imported + " profiles imported");
            field_22787.method_1507(new ProfileSelectorScreen(parent));
        }).method_46434(field_22789 / 2 - 60, footerY, 62, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Back"), button -> field_22787.method_1507(parent))
                .method_46434(field_22789 / 2 + 8, footerY, 92, 20).method_46431());
    }

    private void select(KitProfile profile) {
        KitArrangerClient.get().getProfileManager().setActiveName(profile.name);
        field_22787.method_1507(parent);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_57736(context, 0, 0, field_22789, field_22790);
        ProfileManager manager = KitArrangerClient.get().getProfileManager();
        int center = field_22789 / 2;
        context.method_27534(field_22793, field_22785, center, 14, 0xFFFFFF);
        context.method_27534(field_22793,
                class_2561.method_43470("Scope: " + manager.getCurrentScope()), center, 29, 0xA8B0BC);
        context.method_27534(field_22793,
                class_2561.method_43470("Created by " + KitArrangerClient.CREATOR), center, 40, 0x58BFFB);
        if (manager.getScopedProfiles().isEmpty()) {
            context.method_27534(field_22793, class_2561.method_43470("No profiles in this scope"), center, field_22790 / 2, 0xA8B0BC);
        }
        KitProfile active = manager.getActiveProfile();
        String activeName = active == null ? "None" : active.name;
        context.method_27534(field_22793, class_2561.method_43470("Active: " + activeName), center, field_22790 - 48, 0x71D38A);
        super.method_25394(context, mouseX, mouseY, delta);
    }
}
