package dev.kitarranger.ui;

import dev.kitarranger.inventory.InventoryArranger;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class ConfirmArrangeScreen extends class_437 {
    private final class_437 parent;
    private final Runnable confirm;
    private final InventoryArranger.ArrangementPlan plan;

    public ConfirmArrangeScreen(class_437 parent, Runnable confirm, InventoryArranger.ArrangementPlan plan) {
        super(class_2561.method_43470("Arrange Kit?"));
        this.parent = parent;
        this.confirm = confirm;
        this.plan = plan;
    }

    @Override
    protected void method_25426() {
        int center = field_22789 / 2;
        method_37063(class_4185.method_46430(class_2561.method_43470("Arrange"), button -> confirm.run()).method_46434(center - 100, field_22790 / 2 + 4, 96, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), button -> field_22787.method_1507(parent)).method_46434(center + 4, field_22790 / 2 + 4, 96, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_57736(context, 0, 0, field_22789, field_22790);
        context.method_27534(field_22793, field_22785, field_22789 / 2, field_22790 / 2 - 58, 0xFFFFFF);
        context.method_27534(field_22793,
                class_2561.method_43470("Will arrange " + plan.arrangedCount() + " kit slots"), field_22789 / 2, field_22790 / 2 - 40, 0x71D38A);
        context.method_27534(field_22793,
                class_2561.method_43470(plan.missingCount() + " missing; " + plan.lockedCount() + " locked; unchanged items stay put"),
                field_22789 / 2, field_22790 / 2 - 24, 0xA8B0BC);
        super.method_25394(context, mouseX, mouseY, delta);
    }
}
