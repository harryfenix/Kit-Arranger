package dev.kitarranger.ui;

import dev.kitarranger.KitArrangerClient;
import dev.kitarranger.config.KitArrangerSettings;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class SettingsScreen extends class_437 {
    private final class_437 parent;
    private final KitArrangerSettings settings;

    public SettingsScreen(class_437 parent) {
        super(class_2561.method_43470("Kit Arranger Settings"));
        this.parent = parent;
        this.settings = KitArrangerClient.get().getSettings();
    }

    @Override
    protected void method_25426() {
        int left = field_22789 / 2 - 120;
        int y = 54;
        method_37063(class_4185.method_46430(delayText(), button -> {
            int[] values = {20, 40, 60, 80, 100};
            int current = 0;
            for (int i = 0; i < values.length; i++) if (values[i] == settings.actionDelayMs) current = i;
            settings.actionDelayMs = values[(current + 1) % values.length];
            button.method_25355(delayText());
        }).method_46434(left, y, 240, 20).method_46431());
        method_37063(class_4185.method_46430(toggleText("Inventory buttons", settings.showInventoryButtons), button -> {
            settings.showInventoryButtons = !settings.showInventoryButtons;
            button.method_25355(toggleText("Inventory buttons", settings.showInventoryButtons));
        }).method_46434(left, y + 25, 240, 20).method_46431());
        method_37063(class_4185.method_46430(toggleText("Show profile name", settings.showProfileName), button -> {
            settings.showProfileName = !settings.showProfileName;
            button.method_25355(toggleText("Show profile name", settings.showProfileName));
        }).method_46434(left, y + 50, 240, 20).method_46431());
        method_37063(class_4185.method_46430(toggleText("Highlight kit items", settings.highlightKitItems), button -> {
            settings.highlightKitItems = !settings.highlightKitItems;
            button.method_25355(toggleText("Highlight kit items", settings.highlightKitItems));
        }).method_46434(left, y + 75, 240, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Done"), button -> {
            KitArrangerClient.get().saveSettings();
            field_22787.method_1507(parent);
        }).method_46434(left, field_22790 - 32, 240, 20).method_46431());
    }

    private class_2561 delayText() { return class_2561.method_43470("Action delay: " + settings.actionDelayMs + " ms"); }
    private class_2561 toggleText(String label, boolean value) { return class_2561.method_43470(label + ": " + (value ? "ON" : "OFF")); }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_57736(context, 0, 0, field_22789, field_22790);
        context.method_27534(field_22793, field_22785, field_22789 / 2, 16, 0xFFFFFF);
        context.method_27534(field_22793, class_2561.method_43470("Fast, synchronized, legitimate inventory actions"), field_22789 / 2, 28, 0xA8B0BC);
        context.method_27534(field_22793, class_2561.method_43470("Change P and K in Options > Controls > Key Binds"), field_22789 / 2, 40, 0x58BFFB);
        super.method_25394(context, mouseX, mouseY, delta);
    }
}
