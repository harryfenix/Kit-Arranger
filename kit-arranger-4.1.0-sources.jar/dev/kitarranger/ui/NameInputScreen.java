package dev.kitarranger.ui;

import dev.kitarranger.KitArrangerClient;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class NameInputScreen extends class_437 {
    private final class_437 parent;
    private class_342 nameField;

    public NameInputScreen(class_437 parent) {
        super(class_2561.method_43470("Save Kit Profile"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int center = field_22789 / 2;
        nameField = new class_342(field_22793, center - 100, field_22790 / 2 - 20, 200, 20, class_2561.method_43470("Profile name"));
        nameField.method_1880(32);
        method_37063(nameField);
        method_37063(class_4185.method_46430(class_2561.method_43470("Save"), button -> save()).method_46434(center - 100, field_22790 / 2 + 12, 96, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), button -> field_22787.method_1507(parent)).method_46434(center + 4, field_22790 / 2 + 12, 96, 20).method_46431());
        method_48265(nameField);
    }

    private void save() {
        String name = nameField.method_1882().trim();
        if (!name.isEmpty()) KitArrangerClient.get().saveCurrentProfile(field_22787, name, parent);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_57736(context, 0, 0, field_22789, field_22790);
        context.method_27534(field_22793, field_22785, field_22789 / 2, field_22790 / 2 - 52, 0xFFFFFF);
        context.method_27534(field_22793, class_2561.method_43470("Name this inventory arrangement"), field_22789 / 2, field_22790 / 2 - 38, 0xA8B0BC);
        super.method_25394(context, mouseX, mouseY, delta);
    }
}
