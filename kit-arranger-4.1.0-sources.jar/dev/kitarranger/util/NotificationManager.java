package dev.kitarranger.util;

import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class NotificationManager {
    private NotificationManager() { }
    public static void success(class_310 client, String message) {
        if (client.field_1724 != null) client.field_1724.method_7353(class_2561.method_43470("✓ " + message), true);
    }
    public static void warn(class_310 client, String message) {
        if (client.field_1724 != null) client.field_1724.method_7353(class_2561.method_43470("⚠ " + message), true);
    }
    public static void info(class_310 client, String message) {
        if (client.field_1724 != null) client.field_1724.method_7353(class_2561.method_43470(message), true);
    }
}
