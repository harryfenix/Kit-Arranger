package dev.kitarranger;

import dev.kitarranger.config.ConfigManager;
import dev.kitarranger.config.KitArrangerSettings;
import dev.kitarranger.inventory.InventoryActionQueue;
import dev.kitarranger.inventory.InventoryArranger;
import dev.kitarranger.profile.KitProfile;
import dev.kitarranger.profile.ProfileManager;
import dev.kitarranger.ui.NameInputScreen;
import dev.kitarranger.ui.ProfileSelectorScreen;
import dev.kitarranger.ui.SettingsScreen;
import dev.kitarranger.util.NotificationManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_490;
import dev.kitarranger.mixin.ScreenAccessor;
import org.lwjgl.glfw.GLFW;

public final class KitArrangerClient implements ClientModInitializer {
    public static final String MOD_ID = "kitarranger";
    public static final String VERSION = "4.2.1";
    public static final String CREATOR = "HARRY_FENIX";
    private static KitArrangerClient instance;

    private ProfileManager profileManager;
    private KitArrangerSettings settings;
    private InventoryActionQueue actionQueue;
    private InventoryArranger arranger;
    private class_304 openProfilesKey;
    private class_304 quickArrangeKey;

    public static KitArrangerClient get() {
        return instance;
    }

    @Override
    public void onInitializeClient() {
        instance = this;
        ConfigManager config = new ConfigManager();
        settings = config.loadSettings();
        profileManager = new ProfileManager(config);
        profileManager.load();
        actionQueue = new InventoryActionQueue(settings);
        arranger = new InventoryArranger(actionQueue, profileManager, settings);

        class_304.class_11900 keyCategory = class_304.class_11900.method_74698(class_2960.method_60655(MOD_ID, "keybinds"));
        openProfilesKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.kitarranger.open_profiles", class_3675.class_307.field_1668, GLFW.GLFW_KEY_P,
                keyCategory));
        quickArrangeKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.kitarranger.quick_arrange", class_3675.class_307.field_1668, GLFW.GLFW_KEY_K,
                keyCategory));

        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof class_490 inventory) addInventoryControls(client, inventory);
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            profileManager.updateScope(client);
            actionQueue.tick(client);
            while (openProfilesKey.method_1436() && client.field_1755 instanceof class_490 inventory) {
                client.method_1507(new ProfileSelectorScreen(inventory));
            }
            while (quickArrangeKey.method_1436() && client.field_1755 instanceof class_490 inventory) {
                requestArrange(client, inventory);
            }
        });
    }

    private void addInventoryControls(class_310 client, class_490 screen) {
        if (!settings.showInventoryButtons()) return;
        int panelY = (screen.field_22790 - 166) / 2 + 168;
        int width = 68;
        int gap = 3;
        int panelWidth = width * 4 + gap * 3;
        int startX = (screen.field_22789 - panelWidth) / 2;
        ScreenAccessor accessor = (ScreenAccessor) screen;
        accessor.kitarranger$addDrawableChild(net.minecraft.class_4185.method_46430(class_2561.method_43470("Save Kit"),
                button -> client.method_1507(new NameInputScreen(screen))).method_46434(startX, panelY, width, 18).method_46431());
        accessor.kitarranger$addDrawableChild(net.minecraft.class_4185.method_46430(
                class_2561.method_43470(arranger.isRunning() ? "Cancel" : "Arrange"), button -> {
                    if (arranger.isRunning()) {
                        arranger.cancel(client);
                    } else {
                        requestArrange(client, screen);
                    }
                    button.method_25355(class_2561.method_43470(arranger.isRunning() ? "Cancel" : "Arrange"));
                }).method_46434(startX + (width + gap), panelY, width, 18).method_46431());
        accessor.kitarranger$addDrawableChild(net.minecraft.class_4185.method_46430(class_2561.method_43470("Dashboard"),
                button -> client.method_1507(new ProfileSelectorScreen(screen))).method_46434(startX + (width + gap) * 2, panelY, width, 18).method_46431());
        accessor.kitarranger$addDrawableChild(net.minecraft.class_4185.method_46430(class_2561.method_43470("Settings"),
                button -> client.method_1507(new SettingsScreen(screen))).method_46434(startX + (width + gap) * 3, panelY, width, 18).method_46431());
    }

    public void requestArrange(class_310 client, class_437 returnScreen) {
        KitProfile active = profileManager.getActiveProfile();
        if (active == null) {
            NotificationManager.warn(client, "No active kit profile");
            return;
        }
        InventoryArranger.ArrangementPlan plan = arranger.preview(client);
        if (plan == null) return;
        arranger.arrange(client, plan);
    }

    public void saveCurrentProfile(class_310 client, String name, class_437 returnScreen) {
        if (client.field_1724 == null) return;
        profileManager.saveFromPlayer(name, client.field_1724);
        profileManager.setActiveName(name);
        NotificationManager.success(client, name + " profile saved");
        client.method_1507(returnScreen);
    }

    public ProfileManager getProfileManager() { return profileManager; }
    public KitArrangerSettings getSettings() { return settings; }
    public void saveSettings() { new ConfigManager().saveSettings(settings); }
    public InventoryArranger getArranger() { return arranger; }
}
