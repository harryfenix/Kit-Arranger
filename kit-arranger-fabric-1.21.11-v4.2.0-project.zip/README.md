# Kit Arranger

Client-side inventory profile organizer for Minecraft Fabric 1.21.11.

## Build

Requirements: Java 21 and an internet connection for the first Gradle dependency download.

```text
gradlew build
```

The release jar is written to `build/libs/kit-arranger-4.2.0.jar`. Copy that jar to the Fabric `mods` folder alongside Fabric API. The `-sources.jar` is only for development.

## Versioning

Release versions use semantic versioning. Bug fixes increment the last number, new features increment the middle number, and breaking changes increment the first number. Every release uses a new JAR filename so older builds are easy to identify.

## Use

1. Open the normal player inventory.
2. Arrange the kit manually and click **Save Profile**.
3. Select the profile from **Profiles** when needed.
4. Click **Arrange** or press **K**.

Profiles are stored in `config/kitarranger/profiles.json`; settings are stored in `config/kitarranger/settings.json`.

The arranger records only non-empty slots 5–45 of the player screen handler, including armor and offhand. During arrangement it matches existing stacks, plans swaps in memory, and submits normal `PICKUP` `clickSlot` actions. It never creates, deletes, splits, or modifies an item. If the screen changes or any expected slot changes while the queue is running, the queue cancels automatically.

Version 1.2.0 adds an arrangement preview, progress messages, a Cancel button, and optional locks for the hotbar, armor, and offhand. Missing kit items are skipped and unrelated items remain untouched.

Version 2.0.0 redesigned profile management as a dashboard. Version 3.0.0 is the v1.2.0 stability release: each pickup click waits for the inventory state to update, every planned kit slot is verified three times after arranging, and BASIC/STRICT matching is fixed per arrangement plan. It also makes the redesign visible in-game with a status card, version label, clearer controls, active profile/scope information, and a dashboard-oriented inventory toolbar. Profiles are automatically scoped to global, single-player, or multiplayer server contexts. The dashboard supports selecting, duplicating, deleting, importing, and exporting profiles. Profile saves also keep a `profiles.json.bak` backup.

Branding: the supplied Kit Arranger logo is included as the Fabric mod icon, and the project is credited to `HARRY_FENIX`.

Version 4.0.0 always uses strict item matching. The settings screen is simplified to action delay, inventory buttons, profile name, and kit highlighting. The old matching, confirmation, and slot-lock controls were removed so arranging uses the saved item properties automatically.

Version 4.1.0 adds clearly documented customizable keybinds. Open `Options > Controls > Key Binds`, find the Kit Arranger category, and choose any keys for Open Kit Profiles and Quick Arrange.

Version 4.2.0 removes the green inventory status board for a cleaner screen.

## Controls

- `K`: Quick Arrange
- `P`: Open Kit Profiles while the inventory is open
- Both keys are configurable from Minecraft's Controls menu.

## Matching

- **Basic**: item ID.
- **Strict**: item ID plus the current component signature, covering relevant item data such as enchantments, custom names, and potion components.

The action delay is configurable at 20, 40, 60, 80, or 100 ms, with 60 ms as the default. This is a client-side organizer and does not bypass server inventory synchronization or anti-cheat systems.
