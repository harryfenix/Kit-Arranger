package dev.kitarranger.inventory;

import dev.kitarranger.config.KitArrangerSettings;
import dev.kitarranger.profile.KitProfile;
import dev.kitarranger.profile.ProfileManager;
import dev.kitarranger.util.NotificationManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.PlayerScreenHandler;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public final class InventoryArranger {
    private final InventoryActionQueue queue;
    private final ProfileManager profiles;
    private final KitArrangerSettings settings;

    public InventoryArranger(InventoryActionQueue queue, ProfileManager profiles, KitArrangerSettings settings) {
        this.queue = queue;
        this.profiles = profiles;
        this.settings = settings;
    }

    public void arrange(MinecraftClient client) {
        ArrangementPlan plan = preview(client);
        if (plan != null) arrange(client, plan);
    }

    public ArrangementPlan preview(MinecraftClient client) {
        if (client.player == null || !(client.currentScreen instanceof InventoryScreen)
                || !(client.player.currentScreenHandler instanceof PlayerScreenHandler handler)) {
            NotificationManager.warn(client, "Open your inventory before arranging");
            return null;
        }
        KitProfile profile = profiles.getActiveProfile();
        if (profile == null || profile.slots.isEmpty()) {
            NotificationManager.warn(client, "No active kit profile");
            return null;
        }

        ItemStack[] simulated = new ItemStack[handler.slots.size()];
        for (int i = 0; i < simulated.length; i++) simulated[i] = handler.getSlot(i).getStack().copy();
        List<InventoryActionQueue.Action> actions = new ArrayList<>();
        int missing = 0;
        int arranged = 0;
        int locked = 0;

        for (Map.Entry<Integer, KitProfile.SavedSlot> entry : profile.slots.entrySet().stream()
                .sorted(Comparator.comparingInt(Map.Entry::getKey)).toList()) {
            int target = entry.getKey();
            KitProfile.SavedSlot saved = entry.getValue();
            if (target < 5 || target > 45 || target >= simulated.length) continue;
            if (InventoryMatcher.matches(simulated[target], saved)) continue;

            int source = findSource(simulated, target, saved);
            if (source < 0) {
                missing++;
                continue;
            }

            ItemStack sourceStack = simulated[source].copy();
            ItemStack targetStack = simulated[target].copy();
            actions.add(new InventoryActionQueue.Action(source, sourceStack.copy(), ItemStack.EMPTY));
            actions.add(new InventoryActionQueue.Action(target, targetStack.copy(), sourceStack.copy()));
            // A pickup swap needs a third click to place the target stack back into the source slot.
            actions.add(new InventoryActionQueue.Action(source, ItemStack.EMPTY, targetStack.copy()));
            arranged++;

            simulated[source] = targetStack;
            simulated[target] = sourceStack;
        }

        if (actions.isEmpty()) {
            if (missing > 0) {
                NotificationManager.info(client, "Nothing arranged — missing " + missing + " kit items");
            } else if (locked > 0) {
                NotificationManager.info(client, "Nothing arranged — " + locked + " kit slots locked");
            } else {
                NotificationManager.info(client, "Kit already arranged");
            }
            return null;
        }

        return new ArrangementPlan(profile.name, handler, List.copyOf(actions), arranged, missing, locked);
    }

    public void arrange(MinecraftClient client, ArrangementPlan plan) {
        if (client.player == null || !(client.currentScreen instanceof InventoryScreen)
                || client.player.currentScreenHandler != plan.handler()) {
            NotificationManager.warn(client, "Inventory changed — preview cancelled");
            return;
        }
        queue.enqueue(plan.handler(), plan.actions(), plan.arrangedCount(),
                (done, total) -> NotificationManager.info(client, "Arranging kit: " + done + "/" + total),
                () -> {
                    if (verifyPlacement(plan)) {
                        NotificationManager.success(client, "Arranged and verified " + plan.arrangedCount() + " kit slots");
                    } else {
                        NotificationManager.warn(client, "Arrangement finished, but some slots failed verification");
                    }
                    if (plan.missingCount() > 0) {
                        NotificationManager.warn(client, "Missing " + plan.missingCount() + " kit items");
                    }
                    if (plan.lockedCount() > 0) {
                        NotificationManager.info(client, "Skipped " + plan.lockedCount() + " locked kit slots");
                    }
                },
                () -> { });
    }

    public boolean isRunning() { return queue.isRunning(); }

    public void cancel(MinecraftClient client) { queue.cancel(client); }

    private int findSource(ItemStack[] simulated, int target, KitProfile.SavedSlot saved) {
        for (int slot = 5; slot <= 45 && slot < simulated.length; slot++) {
            if (slot != target && InventoryMatcher.matches(simulated[slot], saved)) return slot;
        }
        return -1;
    }

    private boolean verifyPlacement(ArrangementPlan plan) {
        if (plan.handler() == null || profiles.getActiveProfile() == null
                || !profiles.getActiveProfile().name.equals(plan.profileName())) return false;
        boolean verified = true;
        // Check every target three times so a delayed client update cannot be reported as success.
        for (int pass = 0; pass < 3; pass++) {
            for (Map.Entry<Integer, KitProfile.SavedSlot> entry : profiles.getActiveProfile().slots.entrySet()) {
                int target = entry.getKey();
                if (target < 5 || target > 45 || target >= plan.handler().slots.size()) continue;
                if (!InventoryMatcher.matches(plan.handler().getSlot(target).getStack(), entry.getValue())) {
                    verified = false;
                }
            }
        }
        return verified;
    }

    public record ArrangementPlan(String profileName, PlayerScreenHandler handler,
                                  List<InventoryActionQueue.Action> actions,
                                  int arrangedCount, int missingCount, int lockedCount) { }
}
