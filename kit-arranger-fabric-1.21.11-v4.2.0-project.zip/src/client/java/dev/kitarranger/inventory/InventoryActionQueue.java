package dev.kitarranger.inventory;

import dev.kitarranger.config.KitArrangerSettings;
import dev.kitarranger.util.NotificationManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Queue;
import java.util.function.BiConsumer;

public final class InventoryActionQueue {
    private final KitArrangerSettings settings;
    private final Queue<Action> actions = new ArrayDeque<>();
    private PlayerScreenHandler handler;
    private Runnable onComplete = () -> { };
    private Runnable onCancel = () -> { };
    private BiConsumer<Integer, Integer> onProgress = (done, total) -> { };
    private Action awaiting;
    private long nextActionAt;
    private long actionSentAt;
    private int completedActions;
    private int totalMoves;
    private boolean running;

    public InventoryActionQueue(KitArrangerSettings settings) { this.settings = settings; }

    public void enqueue(PlayerScreenHandler handler, Collection<Action> planned, int totalMoves,
                        BiConsumer<Integer, Integer> onProgress, Runnable onComplete, Runnable onCancel) {
        cancel(null);
        this.handler = handler;
        this.actions.addAll(planned);
        this.totalMoves = Math.max(0, totalMoves);
        this.completedActions = 0;
        this.onProgress = onProgress == null ? (done, total) -> { } : onProgress;
        this.onComplete = onComplete == null ? () -> { } : onComplete;
        this.onCancel = onCancel == null ? () -> { } : onCancel;
        this.awaiting = null;
        this.nextActionAt = 0L;
        this.running = !actions.isEmpty();
    }

    public void tick(MinecraftClient client) {
        if (!running) return;
        if (client.player == null || client.interactionManager == null
                || !(client.currentScreen instanceof InventoryScreen)
                || client.player.currentScreenHandler != handler) {
            cancel(client);
            return;
        }
        long now = System.currentTimeMillis();
        if (awaiting != null) {
            if (sameStack(handler.getSlot(awaiting.slot()).getStack(), awaiting.after())) {
                actions.remove();
                completedActions++;
                if (completedActions % 3 == 0 || actions.isEmpty()) {
                    onProgress.accept(Math.min(totalMoves, (completedActions + 2) / 3), totalMoves);
                }
                awaiting = null;
                nextActionAt = now + Math.max(20, Math.min(100, settings.actionDelayMs()));
                if (actions.isEmpty()) finish();
                return;
            }
            if (now - actionSentAt < Math.max(1000L, settings.actionDelayMs() * 8L)) return;
            cancel(client);
            return;
        }
        if (now < nextActionAt) return;

        Action action = actions.peek();
        if (action == null) {
            finish();
            return;
        }
        if (action.slot() < 5 || action.slot() > 45 || action.slot() >= handler.slots.size()
                || !sameStack(handler.getSlot(action.slot()).getStack(), action.expected())) {
            cancel(client);
            return;
        }

        client.interactionManager.clickSlot(handler.syncId, action.slot(), 0, SlotActionType.PICKUP, client.player);
        awaiting = action;
        actionSentAt = now;
    }

    public boolean isRunning() { return running; }

    public void cancel(MinecraftClient client) {
        if (!running) {
            actions.clear();
            return;
        }
        running = false;
        actions.clear();
        awaiting = null;
        onProgress = (done, total) -> { };
        Runnable callback = onCancel;
        onCancel = () -> { };
        callback.run();
        if (client != null) NotificationManager.warn(client, "Inventory changed — arrangement cancelled");
    }

    private void finish() {
        running = false;
        actions.clear();
        awaiting = null;
        onProgress.accept(totalMoves, totalMoves);
        onProgress = (done, total) -> { };
        Runnable callback = onComplete;
        onComplete = () -> { };
        callback.run();
    }

    private static boolean sameStack(ItemStack left, ItemStack right) {
        if (left.isEmpty() || right.isEmpty()) return left.isEmpty() && right.isEmpty();
        return left.getCount() == right.getCount()
                && Registries.ITEM.getId(left.getItem()).equals(Registries.ITEM.getId(right.getItem()))
                && left.getComponents().toString().equals(right.getComponents().toString());
    }

    public record Action(int slot, ItemStack expected, ItemStack after) { }
}
