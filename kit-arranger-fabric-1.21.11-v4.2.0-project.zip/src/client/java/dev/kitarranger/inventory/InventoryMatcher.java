package dev.kitarranger.inventory;

import dev.kitarranger.profile.KitProfile;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;

public final class InventoryMatcher {
    private InventoryMatcher() { }

    public static boolean matches(ItemStack current, KitProfile.SavedSlot saved) {
        if (current == null || current.isEmpty() || saved == null) return false;
        if (!Registries.ITEM.getId(current.getItem()).toString().equals(saved.itemId)) return false;
        return current.getComponents().toString().equals(saved.components);
    }
}
