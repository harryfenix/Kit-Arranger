package dev.kitarranger.ui;

import dev.kitarranger.inventory.InventoryArranger;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class ConfirmArrangeScreen extends Screen {
    private final Screen parent;
    private final Runnable confirm;
    private final InventoryArranger.ArrangementPlan plan;

    public ConfirmArrangeScreen(Screen parent, Runnable confirm, InventoryArranger.ArrangementPlan plan) {
        super(Text.literal("Arrange Kit?"));
        this.parent = parent;
        this.confirm = confirm;
        this.plan = plan;
    }

    @Override
    protected void init() {
        int center = width / 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("Arrange"), button -> confirm.run()).dimensions(center - 100, height / 2 + 4, 96, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), button -> client.setScreen(parent)).dimensions(center + 4, height / 2 + 4, 96, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderDarkening(context, 0, 0, width, height);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 58, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Will arrange " + plan.arrangedCount() + " kit slots"), width / 2, height / 2 - 40, 0x71D38A);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal(plan.missingCount() + " missing; " + plan.lockedCount() + " locked; unchanged items stay put"),
                width / 2, height / 2 - 24, 0xA8B0BC);
        super.render(context, mouseX, mouseY, delta);
    }
}
