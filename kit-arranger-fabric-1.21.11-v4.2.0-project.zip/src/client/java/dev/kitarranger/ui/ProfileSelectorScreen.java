package dev.kitarranger.ui;

import dev.kitarranger.KitArrangerClient;
import dev.kitarranger.profile.KitProfile;
import dev.kitarranger.profile.ProfileManager;
import dev.kitarranger.util.NotificationManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class ProfileSelectorScreen extends Screen {
    private final Screen parent;

    public ProfileSelectorScreen(Screen parent) {
        super(Text.literal("Kit Arranger v" + KitArrangerClient.VERSION + " Dashboard"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        ProfileManager manager = KitArrangerClient.get().getProfileManager();
        int left = width / 2 - 170;
        int top = 50;
        int index = 0;
        for (KitProfile profile : manager.getScopedProfiles()) {
            int y = top + index++ * 27;
            String label = profile.name.equals(manager.getActiveName()) ? "✓ " + profile.name : profile.name;
            addDrawableChild(ButtonWidget.builder(Text.literal(label), button -> select(profile))
                    .dimensions(left, y, 145, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Copy"), button -> {
                String copy = manager.duplicate(profile.name);
                if (copy != null) NotificationManager.success(client, "Duplicated " + copy);
                client.setScreen(new ProfileSelectorScreen(parent));
            }).dimensions(left + 150, y, 62, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Delete"), button -> {
                manager.delete(profile.name);
                client.setScreen(new ProfileSelectorScreen(parent));
            }).dimensions(left + 217, y, 62, 20).build());
        }

        int footerY = height - 32;
        addDrawableChild(ButtonWidget.builder(Text.literal("Export Active"), button -> {
            NotificationManager.info(client, manager.exportActive() ? "Active profile exported" : "No active profile to export");
        }).dimensions(width / 2 - 170, footerY, 105, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Import"), button -> {
            int imported = manager.importProfiles();
            NotificationManager.info(client, imported + " profiles imported");
            client.setScreen(new ProfileSelectorScreen(parent));
        }).dimensions(width / 2 - 60, footerY, 62, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), button -> client.setScreen(parent))
                .dimensions(width / 2 + 8, footerY, 92, 20).build());
    }

    private void select(KitProfile profile) {
        KitArrangerClient.get().getProfileManager().setActiveName(profile.name);
        client.setScreen(parent);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderDarkening(context, 0, 0, width, height);
        ProfileManager manager = KitArrangerClient.get().getProfileManager();
        int center = width / 2;
        context.drawCenteredTextWithShadow(textRenderer, title, center, 14, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Scope: " + manager.getCurrentScope()), center, 29, 0xA8B0BC);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Created by " + KitArrangerClient.CREATOR), center, 40, 0x58BFFB);
        if (manager.getScopedProfiles().isEmpty()) {
            context.drawCenteredTextWithShadow(textRenderer, Text.literal("No profiles in this scope"), center, height / 2, 0xA8B0BC);
        }
        KitProfile active = manager.getActiveProfile();
        String activeName = active == null ? "None" : active.name;
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Active: " + activeName), center, height - 48, 0x71D38A);
        super.render(context, mouseX, mouseY, delta);
    }
}
