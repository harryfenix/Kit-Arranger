package dev.kitarranger.ui;

import dev.kitarranger.KitArrangerClient;
import dev.kitarranger.config.KitArrangerSettings;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class SettingsScreen extends Screen {
    private final Screen parent;
    private final KitArrangerSettings settings;

    public SettingsScreen(Screen parent) {
        super(Text.literal("Kit Arranger Settings"));
        this.parent = parent;
        this.settings = KitArrangerClient.get().getSettings();
    }

    @Override
    protected void init() {
        int left = width / 2 - 120;
        int y = 54;
        addDrawableChild(ButtonWidget.builder(delayText(), button -> {
            int[] values = {20, 40, 60, 80, 100};
            int current = 0;
            for (int i = 0; i < values.length; i++) if (values[i] == settings.actionDelayMs) current = i;
            settings.actionDelayMs = values[(current + 1) % values.length];
            button.setMessage(delayText());
        }).dimensions(left, y, 240, 20).build());
        addDrawableChild(ButtonWidget.builder(toggleText("Inventory buttons", settings.showInventoryButtons), button -> {
            settings.showInventoryButtons = !settings.showInventoryButtons;
            button.setMessage(toggleText("Inventory buttons", settings.showInventoryButtons));
        }).dimensions(left, y + 25, 240, 20).build());
        addDrawableChild(ButtonWidget.builder(toggleText("Show profile name", settings.showProfileName), button -> {
            settings.showProfileName = !settings.showProfileName;
            button.setMessage(toggleText("Show profile name", settings.showProfileName));
        }).dimensions(left, y + 50, 240, 20).build());
        addDrawableChild(ButtonWidget.builder(toggleText("Highlight kit items", settings.highlightKitItems), button -> {
            settings.highlightKitItems = !settings.highlightKitItems;
            button.setMessage(toggleText("Highlight kit items", settings.highlightKitItems));
        }).dimensions(left, y + 75, 240, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> {
            KitArrangerClient.get().saveSettings();
            client.setScreen(parent);
        }).dimensions(left, height - 32, 240, 20).build());
    }

    private Text delayText() { return Text.literal("Action delay: " + settings.actionDelayMs + " ms"); }
    private Text toggleText(String label, boolean value) { return Text.literal(label + ": " + (value ? "ON" : "OFF")); }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderDarkening(context, 0, 0, width, height);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 16, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Fast, synchronized, legitimate inventory actions"), width / 2, 28, 0xA8B0BC);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Change P and K in Options > Controls > Key Binds"), width / 2, 40, 0x58BFFB);
        super.render(context, mouseX, mouseY, delta);
    }
}
