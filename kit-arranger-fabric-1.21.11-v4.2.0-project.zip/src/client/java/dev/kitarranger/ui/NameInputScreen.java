package dev.kitarranger.ui;

import dev.kitarranger.KitArrangerClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public final class NameInputScreen extends Screen {
    private final Screen parent;
    private TextFieldWidget nameField;

    public NameInputScreen(Screen parent) {
        super(Text.literal("Save Kit Profile"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int center = width / 2;
        nameField = new TextFieldWidget(textRenderer, center - 100, height / 2 - 20, 200, 20, Text.literal("Profile name"));
        nameField.setMaxLength(32);
        addDrawableChild(nameField);
        addDrawableChild(ButtonWidget.builder(Text.literal("Save"), button -> save()).dimensions(center - 100, height / 2 + 12, 96, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), button -> client.setScreen(parent)).dimensions(center + 4, height / 2 + 12, 96, 20).build());
        setInitialFocus(nameField);
    }

    private void save() {
        String name = nameField.getText().trim();
        if (!name.isEmpty()) KitArrangerClient.get().saveCurrentProfile(client, name, parent);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderDarkening(context, 0, 0, width, height);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 52, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Name this inventory arrangement"), width / 2, height / 2 - 38, 0xA8B0BC);
        super.render(context, mouseX, mouseY, delta);
    }
}
