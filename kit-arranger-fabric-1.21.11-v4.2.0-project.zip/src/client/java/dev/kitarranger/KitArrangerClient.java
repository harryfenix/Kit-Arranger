package dev.kitarranger;

import dev.kitarranger.config.ConfigManager;
import dev.kitarranger.config.KitArrangerSettings;
import dev.kitarranger.inventory.InventoryActionQueue;
import dev.kitarranger.inventory.InventoryArranger;
import dev.kitarranger.profile.KitProfile;
import dev.kitarranger.profile.ProfileManager;
import dev.kitarranger.ui.NameInputScreen;
import dev.kitarranger.ui.ProfileSelectorScreen;
import dev.kitarranger.ui.SettingsScreen;
import dev.kitarranger.util.NotificationManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import dev.kitarranger.mixin.ScreenAccessor;
import org.lwjgl.glfw.GLFW;

public final class KitArrangerClient implements ClientModInitializer {
    public static final String MOD_ID = "kitarranger";
    public static final String VERSION = "4.2.0";
    public static final String CREATOR = "HARRY_FENIX";
    private static KitArrangerClient instance;

    private ProfileManager profileManager;
    private KitArrangerSettings settings;
    private InventoryActionQueue actionQueue;
    private InventoryArranger arranger;
    private KeyBinding openProfilesKey;
    private KeyBinding quickArrangeKey;

    public static KitArrangerClient get() {
        return instance;
    }

    @Override
    public void onInitializeClient() {
        instance = this;
        ConfigManager config = new ConfigManager();
        settings = config.loadSettings();
        profileManager = new ProfileManager(config);
        profileManager.load();
        actionQueue = new InventoryActionQueue(settings);
        arranger = new InventoryArranger(actionQueue, profileManager, settings);

        KeyBinding.Category keyCategory = KeyBinding.Category.create(Identifier.of(MOD_ID, "keybinds"));
        openProfilesKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kitarranger.open_profiles", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_P,
                keyCategory));
        quickArrangeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kitarranger.quick_arrange", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K,
                keyCategory));

        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof InventoryScreen inventory) addInventoryControls(client, inventory);
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            profileManager.updateScope(client);
            actionQueue.tick(client);
            while (openProfilesKey.wasPressed() && client.currentScreen instanceof InventoryScreen inventory) {
                client.setScreen(new ProfileSelectorScreen(inventory));
            }
            while (quickArrangeKey.wasPressed() && client.currentScreen instanceof InventoryScreen inventory) {
                requestArrange(client, inventory);
            }
        });
    }

    private void addInventoryControls(MinecraftClient client, InventoryScreen screen) {
        if (!settings.showInventoryButtons()) return;
        int panelY = (screen.height - 166) / 2 + 168;
        int width = 68;
        int gap = 3;
        int panelWidth = width * 4 + gap * 3;
        int startX = (screen.width - panelWidth) / 2;
        ScreenAccessor accessor = (ScreenAccessor) screen;
        accessor.kitarranger$addDrawableChild(net.minecraft.client.gui.widget.ButtonWidget.builder(Text.literal("Save Kit"),
                button -> client.setScreen(new NameInputScreen(screen))).dimensions(startX, panelY, width, 18).build());
        accessor.kitarranger$addDrawableChild(net.minecraft.client.gui.widget.ButtonWidget.builder(
                Text.literal(arranger.isRunning() ? "Cancel" : "Arrange"), button -> {
                    if (arranger.isRunning()) {
                        arranger.cancel(client);
                    } else {
                        requestArrange(client, screen);
                    }
                    button.setMessage(Text.literal(arranger.isRunning() ? "Cancel" : "Arrange"));
                }).dimensions(startX + (width + gap), panelY, width, 18).build());
        accessor.kitarranger$addDrawableChild(net.minecraft.client.gui.widget.ButtonWidget.builder(Text.literal("Dashboard"),
                button -> client.setScreen(new ProfileSelectorScreen(screen))).dimensions(startX + (width + gap) * 2, panelY, width, 18).build());
        accessor.kitarranger$addDrawableChild(net.minecraft.client.gui.widget.ButtonWidget.builder(Text.literal("Settings"),
                button -> client.setScreen(new SettingsScreen(screen))).dimensions(startX + (width + gap) * 3, panelY, width, 18).build());
    }

    public void requestArrange(MinecraftClient client, Screen returnScreen) {
        KitProfile active = profileManager.getActiveProfile();
        if (active == null) {
            NotificationManager.warn(client, "No active kit profile");
            return;
        }
        InventoryArranger.ArrangementPlan plan = arranger.preview(client);
        if (plan == null) return;
        arranger.arrange(client, plan);
    }

    public void saveCurrentProfile(MinecraftClient client, String name, Screen returnScreen) {
        if (client.player == null) return;
        profileManager.saveFromPlayer(name, client.player);
        profileManager.setActiveName(name);
        NotificationManager.success(client, name + " profile saved");
        client.setScreen(returnScreen);
    }

    public ProfileManager getProfileManager() { return profileManager; }
    public KitArrangerSettings getSettings() { return settings; }
    public void saveSettings() { new ConfigManager().saveSettings(settings); }
    public InventoryArranger getArranger() { return arranger; }
}
