package dev.kitarranger.mixin;

import dev.kitarranger.KitArrangerClient;
import dev.kitarranger.profile.KitProfile;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InventoryScreen.class)
public abstract class InventoryScreenMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void kitarranger$renderOverlay(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        InventoryScreen screen = (InventoryScreen) (Object) this;
        KitArrangerClient mod = KitArrangerClient.get();
        if (mod == null) return;
        KitProfile profile = mod.getProfileManager().getActiveProfile();
        int x = (screen.width - 176) / 2;
        int y = (screen.height - 166) / 2;
        if (mod.getSettings().showProfileName() && profile != null) {
            context.drawTextWithShadow(screen.getTextRenderer(), Text.literal("Active Kit: " + profile.name), x, y - 12, 0x71D38A);
        }
        if (profile == null || !mod.getSettings().highlightKitItems()) return;
        for (Slot slot : screen.getScreenHandler().slots) {
            if (profile.slots.containsKey(slot.id)) {
                context.fill(x + slot.x - 1, y + slot.y - 1, x + slot.x + 17, y + slot.y + 17, 0x5538D978);
            }
        }
    }
}
