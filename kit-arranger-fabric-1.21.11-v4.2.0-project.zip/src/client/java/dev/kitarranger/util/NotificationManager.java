package dev.kitarranger.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public final class NotificationManager {
    private NotificationManager() { }
    public static void success(MinecraftClient client, String message) {
        if (client.player != null) client.player.sendMessage(Text.literal("✓ " + message), true);
    }
    public static void warn(MinecraftClient client, String message) {
        if (client.player != null) client.player.sendMessage(Text.literal("⚠ " + message), true);
    }
    public static void info(MinecraftClient client, String message) {
        if (client.player != null) client.player.sendMessage(Text.literal(message), true);
    }
}
