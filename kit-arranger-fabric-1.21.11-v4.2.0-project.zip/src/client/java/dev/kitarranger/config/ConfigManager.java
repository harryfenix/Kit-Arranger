package dev.kitarranger.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import dev.kitarranger.profile.KitProfile;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path directory = FabricLoader.getInstance().getConfigDir().resolve("kitarranger");
    private final Path profilesPath = directory.resolve("profiles.json");
    private final Path exportsDirectory = directory.resolve("exports");
    private final Path settingsPath = directory.resolve("settings.json");

    public ProfilesFile loadProfiles() {
        try (Reader reader = Files.newBufferedReader(profilesPath)) {
            ProfilesFile file = GSON.fromJson(reader, ProfilesFile.class);
            return file == null ? new ProfilesFile() : file;
        } catch (Exception ignored) {
            return new ProfilesFile();
        }
    }

    public KitArrangerSettings loadSettings() {
        try (Reader reader = Files.newBufferedReader(settingsPath)) {
            KitArrangerSettings settings = GSON.fromJson(reader, KitArrangerSettings.class);
            return settings == null ? new KitArrangerSettings() : settings;
        } catch (JsonParseException | java.io.IOException ignored) {
            return new KitArrangerSettings();
        }
    }

    public void saveProfiles(ProfilesFile file) {
        try {
            if (Files.exists(profilesPath)) {
                Files.copy(profilesPath, profilesPath.resolveSibling("profiles.json.bak"), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ignored) { }
        write(profilesPath, file);
    }
    public void saveSettings(KitArrangerSettings settings) { write(settingsPath, settings); }

    public void exportProfile(KitProfile profile) {
        String safeName = profile.name.replaceAll("[^a-zA-Z0-9._-]", "_");
        write(exportsDirectory.resolve(safeName + ".json"), profile);
    }

    public List<KitProfile> importProfiles() {
        List<KitProfile> imported = new ArrayList<>();
        try {
            Files.createDirectories(exportsDirectory);
            try (var files = Files.list(exportsDirectory)) {
                files.filter(path -> path.getFileName().toString().endsWith(".json")).forEach(path -> {
                    try (Reader reader = Files.newBufferedReader(path)) {
                        KitProfile profile = GSON.fromJson(reader, KitProfile.class);
                        if (profile != null && profile.name != null && !profile.name.isBlank()) imported.add(profile);
                    } catch (Exception ignored) { }
                });
            }
        } catch (IOException ignored) { }
        return imported;
    }

    private void write(Path path, Object value) {
        try {
            Files.createDirectories(directory);
            try (Writer writer = Files.newBufferedWriter(path)) { GSON.toJson(value, writer); }
        } catch (java.io.IOException ignored) { }
    }

    public static final class ProfilesFile {
        public String activeProfile = "";
        public Map<String, String> activeByScope = new HashMap<>();
        public List<KitProfile> profiles = new ArrayList<>();
    }
}
