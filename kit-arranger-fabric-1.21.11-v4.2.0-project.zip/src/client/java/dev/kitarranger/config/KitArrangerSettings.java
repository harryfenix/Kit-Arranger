package dev.kitarranger.config;

public final class KitArrangerSettings {
    public int actionDelayMs = 60;
    public boolean showInventoryButtons = true;
    public boolean showProfileName = true;
    public boolean enableAnimations = true;
    public boolean highlightKitItems = true;

    public int actionDelayMs() { return actionDelayMs; }
    public boolean showInventoryButtons() { return showInventoryButtons; }
    public boolean showProfileName() { return showProfileName; }
    public boolean enableAnimations() { return enableAnimations; }
    public boolean highlightKitItems() { return highlightKitItems; }
}
