package dev.kitarranger.profile;

import dev.kitarranger.config.ConfigManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ProfileManager {
    private final ConfigManager config;
    private ConfigManager.ProfilesFile file;
    private String currentScope = "global";

    public ProfileManager(ConfigManager config) { this.config = config; }

    public void load() {
        file = config.loadProfiles();
        if (file.activeByScope == null) file.activeByScope = new HashMap<>();
        for (KitProfile profile : file.profiles) {
            if (profile.scope == null || profile.scope.isBlank()) profile.scope = "global";
        }
    }

    public void updateScope(MinecraftClient client) {
        String next = scopeFor(client);
        if (!next.equals(currentScope)) currentScope = next;
    }

    public String getCurrentScope() { return currentScope; }

    public List<KitProfile> getProfiles() { return file.profiles; }

    public List<KitProfile> getScopedProfiles() {
        return file.profiles.stream().filter(profile -> currentScope.equals(scopeOf(profile))
                || "global".equals(scopeOf(profile))).toList();
    }

    public String getActiveName() {
        String scoped = file.activeByScope.get(currentScope);
        if (scoped != null) return scoped;
        String global = file.activeByScope.get("global");
        return global == null ? file.activeProfile : global;
    }

    public KitProfile getActiveProfile() {
        String activeName = getActiveName();
        return getScopedProfiles().stream().filter(profile -> profile.name.equals(activeName)).findFirst().orElse(null);
    }

    public void setActiveName(String name) {
        file.activeByScope.put(currentScope, name);
        if (currentScope.equals("global")) file.activeProfile = name;
        config.saveProfiles(file);
    }

    public void saveFromPlayer(String name, PlayerEntity player) {
        KitProfile profile = KitProfile.capture(name.trim(), player.getInventory(), currentScope);
        file.profiles.removeIf(existing -> existing.name.equalsIgnoreCase(profile.name)
                && scopeOf(existing).equals(currentScope));
        file.profiles.add(profile);
        config.saveProfiles(file);
    }

    public String duplicate(String name) {
        KitProfile source = getScopedProfiles().stream().filter(profile -> profile.name.equals(name)).findFirst().orElse(null);
        if (source == null) return null;
        String copyName = source.name + " Copy";
        int suffix = 2;
        while (hasScopedProfile(copyName)) {
            copyName = source.name + " Copy " + suffix++;
        }
        KitProfile copy = new KitProfile(copyName);
        copy.scope = currentScope;
        for (Map.Entry<Integer, KitProfile.SavedSlot> entry : source.slots.entrySet()) {
            KitProfile.SavedSlot saved = new KitProfile.SavedSlot();
            saved.count = entry.getValue().count;
            saved.itemId = entry.getValue().itemId;
            saved.components = entry.getValue().components;
            copy.slots.put(entry.getKey(), saved);
        }
        file.profiles.add(copy);
        config.saveProfiles(file);
        return copyName;
    }

    private boolean hasScopedProfile(String name) {
        return getScopedProfiles().stream().anyMatch(profile -> profile.name.equalsIgnoreCase(name));
    }

    public void delete(String name) {
        file.profiles.removeIf(profile -> profile.name.equals(name)
                && (scopeOf(profile).equals(currentScope) || scopeOf(profile).equals("global")));
        if (name.equals(getActiveName())) {
            file.activeByScope.remove(currentScope);
            if (currentScope.equals("global")) file.activeProfile = "";
        }
        config.saveProfiles(file);
    }

    public boolean exportActive() {
        KitProfile active = getActiveProfile();
        if (active == null) return false;
        config.exportProfile(active);
        return true;
    }

    public int importProfiles() {
        int imported = 0;
        for (KitProfile profile : config.importProfiles()) {
            if (profile.scope == null || profile.scope.isBlank()) profile.scope = currentScope;
            if (!profile.scope.equals(currentScope) && !profile.scope.equals("global")) continue;
            file.profiles.removeIf(existing -> existing.name.equalsIgnoreCase(profile.name)
                    && scopeOf(existing).equals(currentScope));
            file.profiles.add(profile);
            imported++;
        }
        if (imported > 0) config.saveProfiles(file);
        return imported;
    }

    private static String scopeOf(KitProfile profile) {
        return profile.scope == null || profile.scope.isBlank() ? "global" : profile.scope;
    }

    private static String scopeFor(MinecraftClient client) {
        if (client.getCurrentServerEntry() != null) return "server:" + client.getCurrentServerEntry().address;
        if (client.isInSingleplayer()) return "singleplayer";
        return "global";
    }
}
