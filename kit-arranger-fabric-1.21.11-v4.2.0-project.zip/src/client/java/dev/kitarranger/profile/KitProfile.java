package dev.kitarranger.profile;

import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.registry.Registries;

import java.util.LinkedHashMap;
import java.util.Map;

public final class KitProfile {
    public String name;
    public String scope = "global";
    public Map<Integer, SavedSlot> slots = new LinkedHashMap<>();

    public KitProfile() { }
    public KitProfile(String name) { this.name = name; }

    public static KitProfile capture(String name, PlayerInventory inventory) {
        return capture(name, inventory, "global");
    }

    public static KitProfile capture(String name, PlayerInventory inventory, String scope) {
        KitProfile profile = new KitProfile(name);
        profile.scope = scope == null || scope.isBlank() ? "global" : scope;
        PlayerScreenHandler handler = new PlayerScreenHandler(inventory, false, inventory.player);
        for (int id = 5; id <= 45 && id < handler.slots.size(); id++) {
            ItemStack stack = handler.getSlot(id).getStack();
            if (!stack.isEmpty()) profile.slots.put(id, SavedSlot.from(stack));
        }
        return profile;
    }

    public static final class SavedSlot {
        public int count;
        public String itemId;
        public String components;

        public static SavedSlot from(ItemStack stack) {
            SavedSlot saved = new SavedSlot();
            saved.count = stack.getCount();
            saved.itemId = Registries.ITEM.getId(stack.getItem()).toString();
            saved.components = stack.getComponents().toString();
            return saved;
        }
    }
}
